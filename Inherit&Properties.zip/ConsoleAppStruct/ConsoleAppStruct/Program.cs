﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppStruct
{
    struct Point
    {
        private double x;
        private double y;

        public Point(double a, double b)
        {
            x = a;
            y = b;
        }

        public void PrintPoint()
        {
            System.Console.WriteLine("({0},{1})", x, y);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            /*
            Point p1 = new Point(4, 7);
            //p1.x = 4;
            //p1.y = 7;
            p1.PrintPoint();
            //Console.WriteLine("({0},{1})", p1.x, p1.y);

            Point p2 = new Point(34, 65);
            //p2.x = Convert.ToDouble(Console.ReadLine());
            //p2.y = 67;
            p2.PrintPoint();
            */

            //AddressFormat a1 = new AddressFormat(12, 43, 1290, "Dhaka");
            Student studentOne = new Student();
            studentOne.Id = 100;//studentOne.SetId(100);//studentOne.id = 100;
            studentOne.Name = "Bruce";//studentOne.SetName("Bruce");//studentOne.name = "Bruce";
            studentOne.Cgpa = 6.45;//studentOne.SetCgpa(6.45);//studentOne.cgpa = 3.45;
            studentOne.Address = new AddressFormat(12, 43, 1290, "Dhaka");//studentOne.SetAddress(new AddressFormat(12, 43, 1290, "Dhaka"));//studentOne.address = a1;
            //studentOne.ShowStudentInfo();
            //Console.WriteLine("{0}", studentOne.Id);

            //AddressFormat a2 = new AddressFormat(22, 98, 1450, "Sylhet");
            Student studentTwo = new Student(200, "Clerk", 8.21, new AddressFormat(22, 98, 1450, "Sylhet"));
            //studentTwo.ShowStudentInfo();

            //type[] array_name = new type[size];
            int[] ax = new int[5] {23, 4, -65, 75, 100};
            for (byte w = 0; w < ax.Length; w++)
            {
            }

            int[,] bx = new int[3, 4] {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}};
            byte r = 0, c;
            while (r < 3)
            {
                c = 0;
                while (c < 4)
                {
                    Console.Write("{0} ", bx[r,c]);
                    c++;
                }
                Console.WriteLine();
                r++;
            }

            int[][] jx = new int[4][];
            jx[0] = new int[3] {0, 1, 2};
            jx[1] = new int[2] {3, 4};
            jx[2] = new int[5] {5, 6, 7, 8, 9};
            jx[3] = new int[1] {10};

            r = 0;
            while (r < jx.Length)
            {
                c = 0;
                while (c < jx[r].Length)
                {
                    Console.Write("{0} ", jx[r][c]);
                    c++;
                }
                Console.WriteLine();
                r++;
            }

            Student[] s = new Student[2];
            s[0] = new Student();
            s[1] = new Student(200, "Clerk", 8.21, new AddressFormat(22, 98, 1450, "Sylhet"));
        }
    }
}
