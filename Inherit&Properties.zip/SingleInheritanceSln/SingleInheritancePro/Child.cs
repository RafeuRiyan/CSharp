﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleInheritancePro
{
    internal class Child : Parent
    {
        internal Child() : base("hj")
        {
            Console.WriteLine("Child DC");
        }
        
        internal Child(int w) : this()
        {
            Console.WriteLine("Child PC " + w);
        }
        
        internal Child(string w) : base(90)
        {
            Console.WriteLine("Child PC " + w);
        }

        internal override void MethodA()
        {
            Console.WriteLine("Child MethodA");
        }

        internal void MethodB()
        {
            Console.WriteLine("Child MethodB");
        }

        internal new void MethodC()
        {
            Console.WriteLine("Child MethodC");
        }

        internal override void MethodD()
        {
            Console.WriteLine("Child MethodD");
        }
    }
}





























/*
internal Child(int u) : base(u)
        {
            Console.WriteLine("Child PC " + u);
        }

        internal Child(string u) : this(30)
        {
            Console.WriteLine("Child PC2 " + u);
        }

        internal override void MethodA()
        {
            Console.WriteLine("Child MethodA");
        }
        
        internal void MethodB()
        {
            Console.WriteLine("Child MethodB");
        }

        internal new void MethodC()
        {
            Console.WriteLine("Parent MethodC");
        }

        internal override void MethodD()
        {
        }
*/