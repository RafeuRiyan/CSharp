﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleInheritancePro
{
    internal abstract class Parent
    {
        internal Parent()
        {
            Console.WriteLine("Parent DC");
        }

        internal Parent(int p) : this()
        {
            Console.WriteLine("Parent PC " + p);
        }
        
        internal Parent(string p) : this(40)
        {
            Console.WriteLine("Parent PC " + p);
        }

        internal virtual void MethodA()
        {
            Console.WriteLine("Parent MethodA");
        }

        internal void MethodB()
        {
            Console.WriteLine("Parent MethodB");
        }

        internal virtual void MethodC()
        {
            Console.WriteLine("Parent MethodC");
        }

        internal abstract void MethodD();
        //internal abstract void MethodE();

    }
}



























/*

internal Parent(int y) : this("djjklsk")
        {
            Console.WriteLine("Parent PC " + y);
        }

        internal Parent(string y) : this()
        {
            Console.WriteLine("Parent PC " + y);
        }

        internal virtual void MethodA()
        {
            Console.WriteLine("Parent MethodA");
        }
        
        internal void MethodB()
        {
            Console.WriteLine("Parent MethodB");
        }
        
        internal virtual void MethodC()
        {
            Console.WriteLine("Parent MethodC");
        }

        internal abstract void MethodD();
        //internal abstract void MethodE();

*/