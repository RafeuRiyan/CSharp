﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleInheritancePro
{
    class Program
    {
        static void Main(string[] args)
        {
            //Sample s = new Sample();
            //int u = Sample.y;
            //int v = s.z;

            //int w = (int)Days.Sunday;
            //Console.WriteLine("{0}", w);

            //Parent p = new Parent(78);
            //Child c = new Child(90);
            //Parent p = new Parent();
            //Child c = new Child();
            
            //p.MethodA();
            //c.MethodA();

            //p.MethodB();
            //c.MethodB();

            //Parent p1 = new Child();
            //p1.MethodA();
            //p1.MethodB();
            //p1.MethodC();
            //Person p = new Person(100, "Bruce", new AddressFormat(1, 2, 333, "Dhaka"), "B+");

            //Student s = new Student(100, "Bruce", new AddressFormat(1, 2, 333, "Dhaka"), "B+", 3.21);
            //s.ShowInfo();

            //Employee e = new Employee(200, "Clerk", new AddressFormat(3,54,7454,"Sylhet"), "O+", 3.45);

            //Person[] persons = new Person[2];
            //persons[0] = new Student(100, "Bruce", new AddressFormat(1, 2, 333, "Dhaka"), "B+", 3.21);
            //persons[1] = new Employee(200, "Clerk", new AddressFormat(3, 54, 7454, "Sylhet"), "O+", 3.45);

            //foreach (Person p in persons)
            //{
            //    p.ShowInfo();
            //    Console.WriteLine();
            //}

            //Country c = new Country();
            //Country.Add();
            Country.Show();
            Country.Search("Clerky");
            //Parent pp = new Child();
        }
    }
}













































/*
//p.MethodA();
            //c.MethodA();

            //p.MethodB();
            //c.MethodB();

            //Parent p1 = new Child();
            //p1.MethodA();
            //p1.MethodB();
            //p1.MethodC();

            //Person p = new Person(100, "Bruce", new AddressFormat(1, 2, 334, "Dhaka"), "B+");
            //Student s = new Student(100, "Bruce", new AddressFormat(1, 2, 334, "Dhaka"), "B+", 3.24);
            //s.ShowInfo();
            //Employee e = new Employee(200, "Clerk", new AddressFormat(3, 4, 2313, "Sylhet"), "O+", 3900);
            //e.ShowInfo();

            Person[] persons = new Person[2];
            persons[0] = new Student(100, "Bruce", new AddressFormat(1, 2, 334, "Dhaka"), "B+", 3.24);
            persons[1] = new Employee(200, "Clerk", new AddressFormat(3, 4, 2313, "Sylhet"), "O+", 3900);

            //foreach (Person p in persons)
            //{
            //    p.ShowInfo();
            //    Console.WriteLine();
            //}

            //Country c = new Country();
            Country.Add(persons[0]);
            Country.Add(persons[1]);
            Country.Add(new Student(300, "Diana", new AddressFormat(1, 2, 334, "Khulna"), "AB+", 3.11));
            Country.Show();
            Country.Search("Cleryk");

            //Parent pp = new Child();// = new Parent();
            //Test t = new Test();
            //int u = Test.y;
            //int v = t.z;

            //int w = (int)OurDays.Sunday;
            //Console.WriteLine("{0}", w);
*/