﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleInheritancePro
{
    internal struct AddressFormat
    {
        private byte houseNo;
        private byte roadNo;
        private ushort postalCode;
        private string district;

        public AddressFormat(byte houseNo, byte roadNo, ushort postalCode, string district)
        {
            this.houseNo = houseNo;
            this.roadNo = roadNo;
            this.postalCode = postalCode;
            this.district = district;
        }

        public void PrintAddress()
        {
            Console.WriteLine("Student Address:");
            Console.WriteLine("House No : {0}", this.houseNo);
            Console.WriteLine("Road No : {0}", this.roadNo);
            Console.WriteLine("Postal Code : {0}", this.postalCode);
            Console.WriteLine("District : {0}", this.district);
        }
    }

    internal abstract class Person
    {
        private int id;
        private string name;
        private AddressFormat homeAddress;
        private string bloodgroup;

        internal int Id
        {
            get { return this.id; }
            set { this.id = value; }
        }

        internal string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        internal AddressFormat HomeAddress
        {
            get { return this.homeAddress; }
            set { this.homeAddress = value; }
        }

        internal string BloodGroup
        {
            get { return this.bloodgroup; }
            set { this.bloodgroup = value; }
        }

        //internal Person()
        //{
        //}

        internal Person(int id, string name, AddressFormat homeAddress, string bloodGroup)
        {
            this.Id = id;
            this.Name = name;
            this.HomeAddress = homeAddress;
            this.BloodGroup = bloodGroup;
        }

        internal virtual void ShowInfo()
        {
            Console.WriteLine("Id: {0}", this.Id);
            Console.WriteLine("Name: {0}", this.Name);
            this.HomeAddress.PrintAddress();
            Console.WriteLine("Blood Group: {0}", this.BloodGroup);
        }

    }

}
