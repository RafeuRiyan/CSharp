﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleInheritancePro
{
    internal enum Days : byte
    {
        Saturday = 100,
        Sunday = 167,
        Monday = 30
    }

    internal class Sample
    {
        public int x;
        public const int y = 200;
        public readonly int z = 300;

        public Sample()
        {
            //y = 56;
            x = y;
            this.z = 34;
        }

        public Sample(int y)
        {
            this.z = 90;
        }

        public void M1()
        {
            //this.z = 89;
        }
    }
}
