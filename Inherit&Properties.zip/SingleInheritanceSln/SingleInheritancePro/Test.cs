﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleInheritancePro
{
    internal enum OurDays : byte
    {
        Saturday = 109,
        Sunday = 98,
        Monday = 30
    }

    internal class Test
    {
        public int x;
        public const int y = 200;
        public readonly int z;

        internal Test()
        {
            this.z = 23;
        }

        internal void M1()
        {
            this.x = y;
            //this.z = 98;
        }
    }
}
